

1. 全新-專案 --> 所有異動
   


2. 既有-專案

   1. 新建 CP  (AA,SPOKEC)
   2. 新建 DE  (UT)(UAT)(PROD)

   3. 刪除 CP  (O)(AA)(SPOKEC)
   4. 刪除 DE  (UT POC完成以後不要了) (不存在-會整個CP刪除)






https://web.mindonmap.com/doc2/31zuD0vWKaEUzYGDO1CfXfzUiYc





1. 全新-專案 --> 所有異動
   


2. 既有-專案

   1. 新建 CP  (AA,SPOKEC)
   2. 新建 DE  (UT)(UAT)(PROD)

   3. 刪除 CP  (O)(AA)(SPOKEC)
   4. 刪除 DE  (UT POC完成以後不要了) (不存在-會整個CP刪除)






https://web.mindonmap.com/doc2/31zuD0vWKaEUzYGDO1CfXfzUiYc

   


有一個網站功能是，業務專案的建立與屬性設定。
畫面上有不同的輸入與按鈕。
請設計一個Oracle Table，功能是 網站畫面的 RBAC 控制。

有3個網站使用者的角色
1. 系統管理員  系統管理員可以操作所有的按鈕
2. 業務主管 有部分輸入與按鈕權限
3. 業務 只能可能觀看，沒有按鈕權限





   




