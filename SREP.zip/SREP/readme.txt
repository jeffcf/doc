

1. 全新-專案 --> 所有異動
   


2. 既有-專案

   1. 新建 CP  (AA,SPOKEC)
   2. 新建 DE  (UT)(UAT)(PROD)

   3. 刪除 CP  (O)(AA)(SPOKEC)
   4. 刪除 DE  (UT POC完成以後不要了) (不存在-會整個CP刪除)






https://web.mindonmap.com/doc2/31zuD0vWKaEUzYGDO1CfXfzUiYc

   




